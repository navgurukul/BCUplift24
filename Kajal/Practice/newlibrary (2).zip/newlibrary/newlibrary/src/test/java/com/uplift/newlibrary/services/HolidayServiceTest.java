package com.uplift.newlibrary.services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

class HolidayServiceTest {

    private HolidayService hs;

    @BeforeEach
    void setUp() {
        hs = new HolidayService();
    }

//    @Test
//    void isHolidayForPUblicHoliday(){
//        assertTrue(hs.getHolidayAPIResponse(LocalDate.of(2022, 1, 26)));
//    }
}