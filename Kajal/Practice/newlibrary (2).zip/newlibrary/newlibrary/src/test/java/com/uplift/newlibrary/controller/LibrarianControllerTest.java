package com.uplift.newlibrary.controller;

import com.uplift.newlibrary.module.Book;
import com.uplift.newlibrary.services.LibraryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;

import static org.mockito.Mockito.when;

import static org.junit.jupiter.api.Assertions.*;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class LibrarianControllerTest {

    @Autowired
    private TestRestTemplate trt;

    @MockBean
    private LibraryService libraryService;

    @Mock
    private Book book;

    @BeforeEach
    void setUp() {
    }

    @Test
    void findBooksById(){
        Book book = new Book("1", "book", "author", "genre", LocalDate.of(2000,12,12), 122.0);
        when(libraryService.findById("1")).thenReturn(book);
        ResponseEntity<Book> response = trt.getForEntity("/librarian/book/1", Book.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(book, response.getBody());
    }
}