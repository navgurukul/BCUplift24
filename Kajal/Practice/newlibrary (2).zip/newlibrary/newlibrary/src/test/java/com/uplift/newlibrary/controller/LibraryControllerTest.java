package com.uplift.newlibrary.controller;

import com.uplift.newlibrary.module.Book;
import com.uplift.newlibrary.services.LibraryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;

import java.time.LocalDate;

import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.*;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class LibraryControllerTest {

    @Autowired
    private TestRestTemplate trt;

    @MockBean
    private LibraryService ls;

    @Mock
    private Book book;

    @BeforeEach
    void setUp() {
    }

    @Test
    void borrow(){
        Book book = new Book("1", "book", "author", "genre", LocalDate.of(2000,12,12), 122.0);
        when(ls.borrowBook("1")).thenReturn(book);

        ResponseEntity<Book> response = trt.postForEntity("/library/book/1?action=borrow", HttpEntity.EMPTY, Book.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(book, response.getBody());
    }
}