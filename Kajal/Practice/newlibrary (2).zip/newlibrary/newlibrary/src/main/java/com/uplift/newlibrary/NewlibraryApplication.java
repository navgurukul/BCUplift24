package com.uplift.newlibrary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewlibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewlibraryApplication.class, args);
	}

}
