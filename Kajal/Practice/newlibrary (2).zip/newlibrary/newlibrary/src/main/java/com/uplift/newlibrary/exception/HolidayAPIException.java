package com.uplift.newlibrary.exception;

public class HolidayAPIException extends RuntimeException{
    public HolidayAPIException(String message){
        super(message);
    }
}
