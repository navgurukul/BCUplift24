package com.uplift.newlibrary.exception;

public class InvailidHolidayAPIInputException extends RuntimeException{
    public InvailidHolidayAPIInputException(String msg){
        super(msg);
    }
}
