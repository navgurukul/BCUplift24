package com.uplift.newlibrary.controller;

import com.uplift.newlibrary.module.Book;
import com.uplift.newlibrary.services.LibraryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/library")
public class LibraryController {

    @Autowired
    private LibraryService ls;

    @RequestMapping("/")
    public String index(){
        return "Welcome to uplift library";
    }

    @PostMapping("/book/{id}")
    public ResponseEntity<Book> borrowBook(@PathVariable String id, @RequestParam String action){
        if (!action.equals("borrow")){
            return null;
        }
        Book b = ls.borrowBook(id);
        if (b==null){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(b);
    }
}
