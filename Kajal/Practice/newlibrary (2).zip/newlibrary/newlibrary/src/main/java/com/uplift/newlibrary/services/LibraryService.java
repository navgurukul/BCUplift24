package com.uplift.newlibrary.services;


import com.uplift.newlibrary.exception.HolidayAPIException;
import com.uplift.newlibrary.exception.InvailidHolidayAPIInputException;
import com.uplift.newlibrary.module.Book;
import com.uplift.newlibrary.exception.LibraryCloseException;
import com.uplift.newlibrary.module.HolidayAPIResponse;
import com.uplift.newlibrary.repository.LIbraryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class LibraryService {

    @Value("${check.holidays}")
    private boolean checkHolidays;

    @Autowired
    private HolidayService hs;

    @Autowired
    private LIbraryRepository lr;


    public Book findById(String id){
        return null;
    }

    public Book borrowBook(String id){
        if(checkHolidays){
            HolidayAPIResponse apiResponse = hs.getHolidayAPIResponse(LocalDate.of(2022, 1, 26));
            if (apiResponse.getStatus()== HttpStatus.OK.value()){
                    if (apiResponse.getHolidays().length>0){
                        throw new LibraryCloseException("Sorry, Library is closed");
                }return lr.borrow(id);
            }else{
                if (apiResponse.getStatus()== HttpStatus.BAD_REQUEST.value()){
                    throw new InvailidHolidayAPIInputException(apiResponse.getError());
                }
                System.err.println("Error while connectiong to holiday service" + apiResponse);
                throw new HolidayAPIException("Sorry, there is an internal erro. Request to connect after sometime");
            }
        }else{
            return lr.borrow(id);
        }
    }
}
