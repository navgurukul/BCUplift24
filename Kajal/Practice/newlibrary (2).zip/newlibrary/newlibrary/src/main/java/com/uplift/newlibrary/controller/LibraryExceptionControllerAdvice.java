package com.uplift.newlibrary.controller;

import com.uplift.newlibrary.exception.HolidayAPIException;
import com.uplift.newlibrary.exception.InvailidHolidayAPIInputException;
import com.uplift.newlibrary.exception.LibraryCloseException;
import com.uplift.newlibrary.repository.LIbraryRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class LibraryExceptionControllerAdvice {
    @ExceptionHandler(value = HolidayAPIException.class)
    public ResponseEntity<Object> handleHolidayAPI(HolidayAPIException e){
        return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = InvailidHolidayAPIInputException.class)
    public ResponseEntity<Object> handleInvailidHoilidayAPI(InvailidHolidayAPIInputException e){
        return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = LibraryCloseException.class)
    public ResponseEntity<Object> handleLibraryCloseException(LibraryCloseException e){
        return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

}
