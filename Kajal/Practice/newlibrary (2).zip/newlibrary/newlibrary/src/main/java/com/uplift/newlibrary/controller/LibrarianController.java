package com.uplift.newlibrary.controller;

import com.uplift.newlibrary.module.Book;
import com.uplift.newlibrary.services.LibraryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/librarian")
public class LibrarianController {

    @Autowired
    private LibraryService libraryService;

    @RequestMapping("/")
    public String index(){
        return "Welcome librarian";
    }

    @GetMapping("/book/{id}")
    public ResponseEntity<Book> findbyId(@PathVariable String id){
        Book book = libraryService.findById(id);
        if (book==null){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(book);
    }
}
