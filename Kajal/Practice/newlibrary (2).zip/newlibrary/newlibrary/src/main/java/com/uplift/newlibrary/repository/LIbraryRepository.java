package com.uplift.newlibrary.repository;

import com.uplift.newlibrary.module.Book;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Repository
public class LIbraryRepository {
    private Set<Book> allBook = new HashSet<>();
    private Map<String, Integer> inventory = new HashMap<>();

    private Map<String, Book> userBookMap = new HashMap<>();

//    public Book findBook(String id){
//        return allBook.stream().filter(book -> book.getId().equals(id)).findFirst().orElse(null);
//    }
    public Book borrow(String id){
//        return findBook(id);
        return new Book("id", "Title", "Author", "genre", LocalDate.of(2022, 2, 11), 200.0);
    }
}
