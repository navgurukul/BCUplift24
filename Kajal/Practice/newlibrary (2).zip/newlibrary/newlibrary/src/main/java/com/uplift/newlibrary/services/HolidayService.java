package com.uplift.newlibrary.services;

import com.uplift.newlibrary.module.HolidayAPIResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;

@Service
public class HolidayService {

    @Autowired
    private RestTemplateBuilder rtb;

    @Value("${holiday.api.key}")
    private String apiKey;

    @Value("${holiday.url}")
    private String apiUrl;


    public HolidayAPIResponse getHolidayAPIResponse(LocalDate date) {
        RestTemplate rt = rtb.build();
        String url = apiUrl + "?key=" + apiKey + "&year="+ date.getYear()+ "&month=" +date.getMonthValue()+
                "&day="+date.getDayOfMonth()+"&country=INR&public=true";

        try{
            ResponseEntity<HolidayAPIResponse> response = rt.getForEntity(url, HolidayAPIResponse.class);
            return response.getBody();
        }

        catch (HttpClientErrorException e){
            String errorMessage = e.getMessage();
            String[] tokens = errorMessage.split(":");
            String statusCode = tokens[0].substring(0,3);
            System.out.println("Status code is: "+ statusCode);

            String error =tokens[tokens.length-2].split("For more information")[0];

            System.out.println("Error is "+error);

            HolidayAPIResponse response = new HolidayAPIResponse();
            response.setStatus(Integer.parseInt(statusCode));
            response.setError(error);
//            System.out.println("Error Response:" + error);
            System.err.println("Error response: "+ response);
            return response;
        }
    }
}
