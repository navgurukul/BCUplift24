package com.uplift.newlibrary.exception;

public class LibraryCloseException extends RuntimeException{
    public LibraryCloseException(String msg){
        super(msg);
    }
}
