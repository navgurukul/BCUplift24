package com.uplift.newlibrary.module;

import java.util.Arrays;

public class HolidayAPIResponse {
    private int status;
    private Holiday[] Holidays;
    private String error;

    public int getStatus() {
        return status;
    }

    public Holiday[] getHolidays() {
        return Holidays;
    }

    public String getError() {
        return error;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public void setHolidays(Holiday[] holidays) {
        Holidays = holidays;
    }

    public void setError(String error) {
        this.error = error;
    }

    @Override
    public String toString() {
        return "HolidayAPIResponse{" +
                "status=" + status +
                ", Holidays=" + Arrays.toString(Holidays) +
                ", error='" + error + '\'' +
                '}';
    }
}
