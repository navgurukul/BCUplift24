package org.uplift.exception;

public class OtpExpireExecption extends Exception {

    public OtpExpireExecption(String message){
        super(message);
    }
}
